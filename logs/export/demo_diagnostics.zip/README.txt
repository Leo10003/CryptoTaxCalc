CryptoTaxCalc Demo Diagnostics
This bundle contains recent logs, the demo build manifest, and a DB snapshot (if available).
